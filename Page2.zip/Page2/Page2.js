// JavaScript for Page2
console.log('Welcome to Page2');